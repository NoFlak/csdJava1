/**
* @author YOUR NAME here
*/


 public class InterestEarned 
 {
     public static void main(String[] args) { 
     // write your code here
     }  
 }

