
import java.util.Scanner;
/**
 *
 * @author Your name here
 */
public class CircleArea {

    
    public static void main(String[] args) {
      
    
    // ********* Problem 2: Circle Area Problem ***********
    
    // TODO Implement the following step-by-step plan
    
    // 1. Declare double constant PI to hold 3.14
    // 2. Declare a double variable to store radius
    // 3. Declare a double variable to store area   
    // 4. Prompt the user to enter radius. 
    // 5. Input radius and store it in variable
    // 6. Calculate circle area. Find the formula on the web if you don't remember it
    // 7. Output the circle's radius and area values in user-friendly fashion
    
    // ********* End of Circle Area Problem code area ***********
  
    }
    
}
